import React from 'react'
import ReactDOM from 'react-dom/client'
import CelexSojournApp from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CelexSojournApp />
  </React.StrictMode>
)
