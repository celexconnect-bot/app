import { useState } from "react";

// ─── Brand & Data ─────────────────────────────────────────────────────────────

const JOURNEY = [
  {
    day: 1,
    date: "Mon 12 Oct",
    location: "Kempinski Hotel, Cancún",
    theme: "Arrival & Welcome",
    emoji: "✦",
    color: "#b8955a",
    activities: [
      { time: "Afternoon", title: "Planner Arrivals & Check-In", desc: "Welcome to Kempinski Hotel Cancún. Settle in and meet your fellow attendees." },
      { time: "Late Afternoon", title: "Hotel Walkthrough & Introductions", desc: "Guided tour of the property with introductions to the venue team." },
      { time: "Evening", title: "Private Welcome Dinner", desc: "An intimate welcome dinner to open the Sojourn." },
    ],
  },
  {
    day: 2,
    date: "Tue 13 Oct",
    location: "Kempinski & Nizuc, Cancún",
    theme: "Destination Immersion",
    emoji: "◈",
    color: "#4a7c59",
    activities: [
      { time: "Morning", title: "Wedding Experience at Kempinski", desc: "Full wedding experience showcase with handpicked local vendors." },
      { time: "Afternoon", title: "Nizuc Venue Site Visit", desc: "Curated site visit to Nizuc Resort & Spa — one of Cancún's most sought-after wedding properties." },
      { time: "Evening", title: "Hosted Dinner & Networking", desc: "Relaxed hosted dinner with time to connect and share insights." },
    ],
  },
  {
    day: 3,
    date: "Wed 14 Oct",
    location: "Isla Mujeres",
    theme: "Island Experience",
    emoji: "◎",
    color: "#6b8fa8",
    activities: [
      { time: "Morning", title: "Transition to Island Destination", desc: "Private transfer to Isla Mujeres — a jewel of the Mexican Caribbean." },
      { time: "Midday", title: "Check-In & Curated Lunch", desc: "Settle into island life with a beautifully curated welcome lunch." },
      { time: "Afternoon & Evening", title: "Planner Interviews & Island Experience", desc: "Intimate planner interviews followed by an exclusive island evening experience." },
    ],
  },
  {
    day: 4,
    date: "Thu 15 Oct",
    location: "Casa Malca, Tulum",
    theme: "Transfers to Tulum",
    emoji: "⟡",
    color: "#8f6b4a",
    activities: [
      { time: "Morning", title: "Transfer from Isla Mujeres to Tulum", desc: "Scenic journey south through the Mexican Caribbean." },
      { time: "Afternoon", title: "Check-In at Casa Malca", desc: "Arrive at the iconic Casa Malca — once Pablo Escobar's estate, now one of Tulum's most celebrated boutique hotels." },
      { time: "Late Afternoon", title: "Venue Walkthrough & Planner Interviews", desc: "In-depth venue exploration with one-on-one planner interview sessions." },
    ],
  },
  {
    day: 5,
    date: "Fri 16 Oct",
    location: "Casa Malca, Tulum",
    theme: "Tulum Experience",
    emoji: "❧",
    color: "#7a5c8f",
    activities: [
      { time: "Morning", title: "Full Venue Showcase & Wedding Setups", desc: "Casa Malca dressed in full wedding splendour — experiencing the spaces as a bride and groom would." },
      { time: "Afternoon", title: "Curated Destination Experience", desc: "A specially crafted afternoon exploring the magic of Tulum's culture, cenotes and coastline." },
      { time: "Evening", title: "Gala Dinner & Celebration", desc: "The pinnacle of the Sojourn — a gala dinner celebrating the destination and the people who bring it to life." },
    ],
  },
  {
    day: 6,
    date: "Sat 17 Oct",
    location: "Tulum",
    theme: "Farewell & Departures",
    emoji: "✿",
    color: "#b8955a",
    activities: [
      { time: "Morning", title: "Closing Breakfast", desc: "A final gathering over breakfast to reflect, connect and plan what comes next." },
      { time: "Late Morning", title: "Departures", desc: "Transfers to Tulum or Cancún International Airport." },
      { time: "Ongoing", title: "Destination Showcase — Dream Wedding Show", desc: "CELEX Sojourn Cancún episode airs on The Dream Wedding Show." },
    ],
  },
];

const VENUES = [
  {
    id: 1,
    name: "Kempinski Hotel Cancún",
    day: "Day 1–2",
    location: "Cancún, Quintana Roo",
    desc: "A flagship of European hospitality on the shores of the Caribbean. With its grand lobby, lush gardens and beachfront terraces, Kempinski sets the stage for weddings of the highest calibre.",
    highlights: ["Beachfront ceremony spaces", "Grand ballroom", "Private beach access", "World-class catering"],
    tag: "Luxury Resort",
    initial: "K",
    color: "#b8955a",
  },
  {
    id: 2,
    name: "Nizuc Resort & Spa",
    day: "Day 2",
    location: "Cancún, Quintana Roo",
    desc: "Nizuc stands apart — a secluded ultra-luxury retreat on its own private peninsula, surrounded by the turquoise waters of the Mexican Caribbean and Mesoamerican reef.",
    highlights: ["Private peninsula setting", "6 unique restaurants", "Over-water spa", "Exclusive wedding villa"],
    tag: "Ultra-Luxury",
    initial: "N",
    color: "#4a7c59",
  },
  {
    id: 3,
    name: "Isla Mujeres",
    day: "Day 3",
    location: "Isla Mujeres, Q. Roo",
    desc: "A jewel of an island just 20 minutes from Cancún — golf-cart streets, powder-white beaches and a pace of life that makes every couple feel like the world was made for them.",
    highlights: ["Car-free island village", "Playa Norte — world-class beach", "Intimate venue options", "Magical sunset views"],
    tag: "Island Destination",
    initial: "I",
    color: "#6b8fa8",
  },
  {
    id: 4,
    name: "Casa Malca, Tulum",
    day: "Day 4–6",
    location: "Tulum, Quintana Roo",
    desc: "Once Pablo Escobar's private Mexican estate — now one of Tulum's most celebrated boutique hotels. Casa Malca blends bohemian luxury with raw jungle-meets-sea drama.",
    highlights: ["Iconic estate history", "Jungle & beachfront settings", "Intimate boutique atmosphere", "Bespoke wedding experiences"],
    tag: "Boutique Icon",
    initial: "C",
    color: "#8f6b4a",
  },
];

const ANNOUNCEMENTS = [
  { id: 1, icon: "📡", title: "Wi-Fi Details", body: "Network: CelexSojourn | Password: Mexico2026 — Available throughout all properties.", pinned: true, time: "Just now" },
  { id: 2, icon: "🧳", title: "Luggage Transfers", body: "All luggage transfers between properties are handled by CELEX. Leave bags with concierge by 08:00 on transfer days.", pinned: true, time: "1 hr ago" },
  { id: 3, icon: "🌿", title: "Gala Dinner Dress Code", body: "Day 5 Gala Dinner: Elegant tropical attire. Think linen, silk and natural tones.", pinned: false, time: "3 hr ago" },
  { id: 4, icon: "🎉", title: "Welcome to the Sojourn", body: "12 of the world's finest wedding planners. 3 extraordinary destinations. 6 unforgettable days. Let's put Mexico on the map.", pinned: false, time: "Yesterday" },
];

const PLANNERS = [
  { id: 1, name: "Attendee 1", region: "🇬🇧 UK", role: "Senior Luxury Planner", initials: "A1", color: "#b8955a" },
  { id: 2, name: "Attendee 2", region: "🇺🇸 USA", role: "Senior Luxury Planner", initials: "A2", color: "#4a7c59" },
  { id: 3, name: "Attendee 3", region: "🇦🇪 UAE", role: "Senior Luxury Planner", initials: "A3", color: "#6b8fa8" },
  { id: 4, name: "Attendee 4", region: "🇫🇷 EUR", role: "Senior Luxury Planner", initials: "A4", color: "#8f6b4a" },
  { id: 5, name: "Attendee 5", region: "🇺🇸 USA", role: "Senior Luxury Planner", initials: "A5", color: "#7a5c8f" },
  { id: 6, name: "Attendee 6", region: "🌍 AFR", role: "Senior Luxury Planner", initials: "A6", color: "#b8955a" },
  { id: 7, name: "Attendee 7", region: "🌏 APAC", role: "Senior Luxury Planner", initials: "A7", color: "#4a7c59" },
  { id: 8, name: "Attendee 8", region: "🇬🇧 UK", role: "Senior Luxury Planner", initials: "A8", color: "#6b8fa8" },
  { id: 9, name: "Attendee 9", region: "🇺🇸 USA", role: "Senior Luxury Planner", initials: "A9", color: "#8f6b4a" },
  { id: 10, name: "Attendee 10", region: "🇦🇪 UAE", role: "Senior Luxury Planner", initials: "A10", color: "#7a5c8f" },
];

const CONTACT = {
  phone: "+44 7354 258845",
  email: "ruel@celex-ensemble.com",
  website: "celex-ensemble.com",
};

// ─── App ──────────────────────────────────────────────────────────────────────
export default function CelexSojournApp() {
  const [tab, setTab] = useState("home");
  const [savedDays, setSavedDays] = useState([]);
  const [selectedDay, setSelectedDay] = useState(null);
  const [selectedVenue, setSelectedVenue] = useState(null);

  const toggleSave = (dayNum) => {
    setSavedDays(s => s.includes(dayNum) ? s.filter(d => d !== dayNum) : [...s, dayNum]);
  };

  const tabs = [
    { id: "home", icon: "⌂", label: "Home" },
    { id: "journey", icon: "◫", label: "Journey" },
    { id: "venues", icon: "◉", label: "Venues" },
    { id: "planners", icon: "◈", label: "Guests" },
    { id: "saved", icon: "♡", label: "Saved", badge: savedDays.length },
    { id: "info", icon: "◎", label: "Info" },
  ];

  return (
    <div style={{
      fontFamily: "'DM Sans', system-ui, sans-serif",
      background: "#f5f0e8",
      minHeight: "100vh",
      color: "#1c2b1a",
      display: "flex",
      flexDirection: "column",
      maxWidth: 480,
      margin: "0 auto",
      position: "relative",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400;1,600&family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 0; }
        @keyframes fadeUp { from { opacity:0; transform:translateY(14px);} to { opacity:1; transform:none;} }
        .fade-up { animation: fadeUp .4s cubic-bezier(.22,1,.36,1) both; }
        @keyframes shimmer { 0%,100%{opacity:.7} 50%{opacity:1} }
        .card-hover { transition: transform .2s, box-shadow .2s; }
        .card-hover:hover { transform: translateY(-3px); box-shadow: 0 12px 40px #b8955a18; }
        .pill-btn { transition: all .18s; }
        .pill-btn:hover { opacity: .85; }
        input, textarea { font-family: 'DM Sans', sans-serif; }
      `}</style>

      {/* Header */}
      <header style={{
        padding: "14px 20px 12px",
        background: "#fffdf8",
        borderBottom: "1px solid #e4d9c6",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        position: "sticky", top: 0, zIndex: 40,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            border: "1.5px solid #b8955a",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontFamily: "Cormorant Garamond, serif", fontSize: 18, fontWeight: 600, color: "#b8955a",
          }}>C</div>
          <div>
            <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 17, fontWeight: 700, letterSpacing: .3, color: "#1c2b1a", lineHeight: 1 }}>CELEX Sojourn</div>
            <div style={{ fontSize: 10, color: "#9e8c6e", letterSpacing: .5, textTransform: "uppercase", marginTop: 1 }}>Mexican Caribbean · Oct 2026</div>
          </div>
        </div>
        <div style={{ background: "#f5f0e8", border: "1px solid #e4d9c6", borderRadius: 8, padding: "5px 10px", fontSize: 11, fontWeight: 600, color: "#b8955a", letterSpacing: .5 }}>12–17 OCT</div>
      </header>

      {/* Content */}
      <div style={{ flex: 1, overflowY: "auto", paddingBottom: 88 }}>
        {tab === "home" && <HomeTab journey={JOURNEY} announcements={ANNOUNCEMENTS} savedDays={savedDays} toggleSave={toggleSave} setTab={setTab} setSelectedDay={setSelectedDay} />}
        {tab === "journey" && <JourneyTab journey={JOURNEY} savedDays={savedDays} toggleSave={toggleSave} selectedDay={selectedDay} setSelectedDay={setSelectedDay} />}
        {tab === "venues" && <VenuesTab venues={VENUES} selectedVenue={selectedVenue} setSelectedVenue={setSelectedVenue} />}
        {tab === "planners" && <PlannersTab planners={PLANNERS} />}
        {tab === "saved" && <SavedTab journey={JOURNEY} savedDays={savedDays} toggleSave={toggleSave} setSelectedDay={setSelectedDay} setTab={setTab} />}
        {tab === "info" && <InfoTab contact={CONTACT} announcements={ANNOUNCEMENTS} />}
      </div>

      {/* Day Detail Sheet */}
      {selectedDay !== null && (
        <DaySheet day={JOURNEY[selectedDay]} saved={savedDays.includes(JOURNEY[selectedDay].day)} toggleSave={toggleSave} onClose={() => setSelectedDay(null)} />
      )}

      {/* Bottom Nav */}
      <nav style={{
        position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)",
        width: "100%", maxWidth: 480,
        background: "#fffdf8",
        borderTop: "1px solid #e4d9c6",
        padding: "8px 0 16px",
        display: "flex", justifyContent: "space-around",
        zIndex: 50,
      }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            background: "none", border: "none", cursor: "pointer",
            display: "flex", flexDirection: "column", alignItems: "center", gap: 3,
            padding: "4px 10px", position: "relative",
            color: tab === t.id ? "#b8955a" : "#9e8c6e",
          }}>
            {tab === t.id && <div style={{ position: "absolute", top: -8, width: 24, height: 2, background: "#b8955a", borderRadius: 2 }} />}
            <span style={{ fontSize: 17 }}>{t.icon}</span>
            <span style={{ fontSize: 10, fontWeight: tab === t.id ? 600 : 400, letterSpacing: .3 }}>{t.label}</span>
            {t.badge > 0 && (
              <span style={{ position: "absolute", top: 0, right: 6, background: "#b8955a", color: "#fff", borderRadius: 9999, fontSize: 9, fontWeight: 700, padding: "1px 4px" }}>{t.badge}</span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
}

// ─── Home Tab ─────────────────────────────────────────────────────────────────
function HomeTab({ journey, announcements, savedDays, toggleSave, setTab, setSelectedDay }) {
  return (
    <div className="fade-up" style={{ padding: "20px 16px 0" }}>
      {/* Hero */}
      <div style={{
        background: "linear-gradient(160deg, #1c2b1a 0%, #2d4a2a 100%)",
        borderRadius: 20, padding: "28px 24px", marginBottom: 24, position: "relative", overflow: "hidden",
      }}>
        <div style={{ position: "absolute", top: -40, right: -40, width: 180, height: 180, background: "radial-gradient(circle, #b8955a25, transparent 70%)", borderRadius: "50%" }} />
        <div style={{ position: "absolute", bottom: -20, left: -20, width: 120, height: 120, background: "radial-gradient(circle, #b8955a15, transparent 70%)", borderRadius: "50%" }} />
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontStyle: "italic", fontSize: 13, color: "#b8955a", letterSpacing: 1, marginBottom: 6 }}>Introducing</div>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 42, fontWeight: 300, lineHeight: 1, color: "#f5f0e8", marginBottom: 4 }}>CELEX</div>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 42, fontWeight: 600, lineHeight: 1, color: "#b8955a", marginBottom: 12 }}>Sojourn</div>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 16, color: "#8faf8a", fontStyle: "italic", marginBottom: 20 }}>Mexican – Caribbean</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {[{ v: "6", l: "Days" }, { v: "3", l: "Destinations" }, { v: "10–12", l: "Elite Planners" }, { v: "$30M+", l: "Wedding Spend" }].map(s => (
            <div key={s.l} style={{ background: "#ffffff10", border: "1px solid #ffffff18", borderRadius: 10, padding: "8px 12px", textAlign: "center" }}>
              <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 18, fontWeight: 600, color: "#b8955a" }}>{s.v}</div>
              <div style={{ fontSize: 10, color: "#8faf8a", marginTop: 1, letterSpacing: .3 }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Route strip */}
      <div style={{ background: "#fffdf8", border: "1px solid #e4d9c6", borderRadius: 14, padding: "14px 16px", marginBottom: 20, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        {["Cancún", "Isla Mujeres", "Tulum"].map((loc, i) => (
          <div key={loc} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "Cormorant Garamond, serif", fontWeight: 600, fontSize: 14, color: "#1c2b1a" }}>{loc}</div>
              <div style={{ fontSize: 10, color: "#9e8c6e" }}>{["Day 1–2", "Day 3", "Day 4–6"][i]}</div>
            </div>
            {i < 2 && <div style={{ fontSize: 14, color: "#d4b87a", margin: "0 2px" }}>→</div>}
          </div>
        ))}
      </div>

      {/* Announcements */}
      <SectionHead title="Announcements" />
      {announcements.filter(a => a.pinned).map(a => (
        <AnnouncementCard key={a.id} a={a} />
      ))}

      {/* Today's Programme */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", margin: "20px 0 10px" }}>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 20, fontWeight: 600 }}>The Journey</div>
        <button onClick={() => setTab("journey")} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#b8955a", fontFamily: "DM Sans, sans-serif" }}>View all →</button>
      </div>
      {journey.map((d, i) => (
        <DayCard key={d.day} d={d} saved={savedDays.includes(d.day)} toggleSave={toggleSave} onClick={() => setSelectedDay(i)} />
      ))}
    </div>
  );
}

// ─── Journey Tab ──────────────────────────────────────────────────────────────
function JourneyTab({ journey, savedDays, toggleSave, selectedDay, setSelectedDay }) {
  return (
    <div className="fade-up" style={{ padding: "20px 16px 0" }}>
      <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 28, fontWeight: 600, marginBottom: 4 }}>The Journey</div>
      <div style={{ fontSize: 12, color: "#9e8c6e", marginBottom: 20, fontStyle: "italic" }}>12th – 17th October 2026</div>
      {journey.map((d, i) => (
        <DayCard key={d.day} d={d} saved={savedDays.includes(d.day)} toggleSave={toggleSave} onClick={() => setSelectedDay(i)} expanded />
      ))}
    </div>
  );
}

function DayCard({ d, saved, toggleSave, onClick, expanded }) {
  return (
    <div className="card-hover" onClick={onClick} style={{
      background: "#fffdf8", border: "1px solid #e4d9c6",
      borderRadius: 16, padding: "16px", marginBottom: 12, cursor: "pointer",
      borderLeft: `3px solid ${d.color}`,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
          <div style={{ background: d.color + "18", border: `1px solid ${d.color}40`, borderRadius: 10, padding: "8px 10px", textAlign: "center", minWidth: 48 }}>
            <div style={{ fontFamily: "Cormorant Garamond, serif", fontWeight: 700, fontSize: 20, color: d.color, lineHeight: 1 }}>{d.day}</div>
            <div style={{ fontSize: 9, color: "#9e8c6e", letterSpacing: .5, textTransform: "uppercase" }}>Day</div>
          </div>
          <div>
            <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 17, fontWeight: 600, lineHeight: 1.2, color: "#1c2b1a" }}>{d.theme}</div>
            <div style={{ fontSize: 12, color: "#9e8c6e", marginTop: 2 }}>{d.date}</div>
            <div style={{ fontSize: 12, color: d.color, marginTop: 3, fontWeight: 500 }}>📍 {d.location}</div>
          </div>
        </div>
        <button onClick={e => { e.stopPropagation(); toggleSave(d.day); }} style={{
          background: "none", border: "none", cursor: "pointer",
          fontSize: 18, color: saved ? "#b8955a" : "#d4c9b4", padding: 0,
          transition: "transform .2s",
        }}>{saved ? "♥" : "♡"}</button>
      </div>
      {expanded && (
        <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid #ede5d4" }}>
          {d.activities.map((act, i) => (
            <div key={i} style={{ display: "flex", gap: 10, marginBottom: i < d.activities.length - 1 ? 8 : 0 }}>
              <div style={{ minWidth: 70, fontSize: 10, color: "#9e8c6e", paddingTop: 2, fontWeight: 500 }}>{act.time}</div>
              <div style={{ fontSize: 13, color: "#3a4a38", lineHeight: 1.4 }}><span style={{ fontWeight: 600 }}>{act.title}</span></div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Venues Tab ───────────────────────────────────────────────────────────────
function VenuesTab({ venues, selectedVenue, setSelectedVenue }) {
  if (selectedVenue) {
    const v = selectedVenue;
    return (
      <div className="fade-up" style={{ padding: "16px" }}>
        <button onClick={() => setSelectedVenue(null)} style={{ background: "#fffdf8", border: "1px solid #e4d9c6", borderRadius: 10, padding: "6px 14px", color: "#9e8c6e", cursor: "pointer", fontSize: 12, marginBottom: 16 }}>← Back</button>
        <div style={{ background: "#fffdf8", border: "1px solid #e4d9c6", borderRadius: 20, padding: 24, marginBottom: 16 }}>
          <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 16 }}>
            <div style={{
              width: 60, height: 60, borderRadius: 14, flexShrink: 0,
              background: v.color + "18", border: `2px solid ${v.color}50`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "Cormorant Garamond, serif", fontSize: 26, fontWeight: 700, color: v.color,
            }}>{v.initial}</div>
            <div>
              <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 22, fontWeight: 700, color: "#1c2b1a" }}>{v.name}</div>
              <div style={{ fontSize: 12, color: "#9e8c6e" }}>{v.location}</div>
              <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
                <span style={{ background: v.color + "18", color: v.color, border: `1px solid ${v.color}30`, borderRadius: 6, fontSize: 10, padding: "2px 7px", fontWeight: 600 }}>{v.tag}</span>
                <span style={{ background: "#f5f0e8", color: "#9e8c6e", border: "1px solid #e4d9c6", borderRadius: 6, fontSize: 10, padding: "2px 7px" }}>{v.day}</span>
              </div>
            </div>
          </div>
          <p style={{ fontSize: 14, color: "#5a6e58", lineHeight: 1.65, fontFamily: "Cormorant Garamond, serif", fontSize: 16, fontWeight: 400 }}>{v.desc}</p>
        </div>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 16, fontWeight: 600, marginBottom: 10, color: "#9e8c6e" }}>Highlights</div>
        {v.highlights.map((h, i) => (
          <div key={i} style={{ background: "#fffdf8", border: "1px solid #e4d9c6", borderRadius: 10, padding: "10px 14px", marginBottom: 8, display: "flex", gap: 10, alignItems: "center" }}>
            <span style={{ color: v.color, fontSize: 14 }}>◆</span>
            <span style={{ fontSize: 13, color: "#3a4a38" }}>{h}</span>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="fade-up" style={{ padding: "20px 16px 0" }}>
      <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 28, fontWeight: 600, marginBottom: 4 }}>The Venues</div>
      <div style={{ fontSize: 12, color: "#9e8c6e", marginBottom: 20, fontStyle: "italic" }}>Three extraordinary destinations</div>
      {venues.map(v => (
        <div key={v.id} className="card-hover" onClick={() => setSelectedVenue(v)} style={{
          background: "#fffdf8", border: "1px solid #e4d9c6", borderRadius: 16,
          padding: "18px", marginBottom: 12, cursor: "pointer",
        }}>
          <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
            <div style={{
              width: 52, height: 52, borderRadius: 12, flexShrink: 0,
              background: v.color + "18", border: `2px solid ${v.color}40`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "Cormorant Garamond, serif", fontSize: 22, fontWeight: 700, color: v.color,
            }}>{v.initial}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 18, fontWeight: 600, color: "#1c2b1a", marginBottom: 2 }}>{v.name}</div>
              <div style={{ fontSize: 11, color: "#9e8c6e", marginBottom: 6 }}>📍 {v.location} · {v.day}</div>
              <span style={{ background: v.color + "18", color: v.color, border: `1px solid ${v.color}30`, borderRadius: 6, fontSize: 10, padding: "2px 8px", fontWeight: 600 }}>{v.tag}</span>
            </div>
            <div style={{ color: "#d4c9b4", fontSize: 16 }}>›</div>
          </div>
          <p style={{ fontSize: 13, color: "#7a8c78", marginTop: 12, lineHeight: 1.55 }}>{v.desc.slice(0, 100)}…</p>
        </div>
      ))}
    </div>
  );
}

// ─── Planners Tab ─────────────────────────────────────────────────────────────
function PlannersTab({ planners }) {
  const regions = ["All", "🇬🇧 UK", "🇺🇸 USA", "🇦🇪 UAE", "🇫🇷 EUR", "🌍 AFR", "🌏 APAC"];
  const [filter, setFilter] = useState("All");
  const filtered = filter === "All" ? planners : planners.filter(p => p.region === filter);

  return (
    <div className="fade-up" style={{ padding: "20px 16px 0" }}>
      <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 28, fontWeight: 600, marginBottom: 2 }}>The Guestlist</div>
      <div style={{ fontSize: 13, color: "#9e8c6e", marginBottom: 16, fontStyle: "italic" }}>10–12 elite luxury wedding planners</div>

      {/* Impact card */}
      <div style={{ background: "linear-gradient(135deg, #1c2b1a, #2d4a2a)", borderRadius: 16, padding: "18px 20px", marginBottom: 20 }}>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontStyle: "italic", fontSize: 14, color: "#8faf8a", marginBottom: 10 }}>Their combined reach</div>
        <div style={{ display: "flex", gap: 16 }}>
          <div>
            <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 32, fontWeight: 600, color: "#b8955a" }}>$30M+</div>
            <div style={{ fontSize: 11, color: "#8faf8a" }}>Annual wedding spend potential</div>
          </div>
          <div style={{ width: 1, background: "#ffffff15" }} />
          <div>
            <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 32, fontWeight: 600, color: "#b8955a" }}>2M+</div>
            <div style={{ fontSize: 11, color: "#8faf8a" }}>Combined audience reach</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 6, marginTop: 14, flexWrap: "wrap" }}>
          {["EUR", "GBR", "USA", "UAE", "AFR", "APAC"].map(r => (
            <span key={r} style={{ background: "#ffffff15", borderRadius: 9999, padding: "3px 10px", fontSize: 10, fontWeight: 600, color: "#d4b87a", letterSpacing: .5 }}>{r}</span>
          ))}
        </div>
      </div>

      {/* Region filter */}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 14, paddingBottom: 2 }}>
        {regions.map(r => (
          <button key={r} className="pill-btn" onClick={() => setFilter(r)} style={{
            background: filter === r ? "#1c2b1a" : "#fffdf8",
            border: `1px solid ${filter === r ? "#1c2b1a" : "#e4d9c6"}`,
            color: filter === r ? "#f5f0e8" : "#9e8c6e",
            borderRadius: 9999, padding: "5px 12px", fontSize: 11, fontWeight: 500,
            cursor: "pointer", whiteSpace: "nowrap",
          }}>{r}</button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {filtered.map(p => (
          <div key={p.id} style={{
            background: "#fffdf8", border: "1px solid #e4d9c6", borderRadius: 14,
            padding: "16px 14px", textAlign: "center",
          }}>
            <div style={{
              width: 50, height: 50, borderRadius: 13, margin: "0 auto 10px",
              background: p.color + "18", border: `2px solid ${p.color}50`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "Cormorant Garamond, serif", fontSize: 16, fontWeight: 700, color: p.color,
            }}>{p.initials}</div>
            <div style={{ fontWeight: 500, fontSize: 13, color: "#1c2b1a" }}>{p.name}</div>
            <div style={{ fontSize: 11, color: "#9e8c6e", marginTop: 2 }}>{p.region}</div>
            <div style={{ fontSize: 10, color: "#b8a990", marginTop: 3 }}>{p.role}</div>
          </div>
        ))}
      </div>
      <div style={{ textAlign: "center", fontSize: 12, color: "#b8a990", fontStyle: "italic", padding: "16px 0 8px" }}>
        Guestlist will be confirmed closer to the event.
      </div>
    </div>
  );
}

// ─── Saved Tab ────────────────────────────────────────────────────────────────
function SavedTab({ journey, savedDays, toggleSave, setSelectedDay, setTab }) {
  const saved = journey.filter(d => savedDays.includes(d.day));
  if (saved.length === 0) {
    return (
      <div className="fade-up" style={{ padding: "60px 24px", textAlign: "center" }}>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 48, color: "#e4d9c6" }}>♡</div>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 22, fontWeight: 400, marginTop: 12, marginBottom: 8 }}>Nothing saved yet</div>
        <div style={{ fontSize: 13, color: "#9e8c6e", lineHeight: 1.6 }}>Tap the ♡ on any day in the Journey to save it here.</div>
        <button onClick={() => setTab("journey")} style={{ marginTop: 20, background: "#1c2b1a", border: "none", borderRadius: 12, padding: "10px 24px", color: "#f5f0e8", fontSize: 13, cursor: "pointer", fontFamily: "DM Sans, sans-serif" }}>Browse the Journey</button>
      </div>
    );
  }
  return (
    <div className="fade-up" style={{ padding: "20px 16px 0" }}>
      <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 28, fontWeight: 600, marginBottom: 4 }}>Saved Days</div>
      <div style={{ fontSize: 12, color: "#9e8c6e", marginBottom: 16 }}>{saved.length} day{saved.length !== 1 ? "s" : ""} saved</div>
      {saved.map((d, i) => (
        <DayCard key={d.day} d={d} saved={true} toggleSave={toggleSave} onClick={() => setSelectedDay(journey.findIndex(j => j.day === d.day))} expanded />
      ))}
    </div>
  );
}

// ─── Info Tab ─────────────────────────────────────────────────────────────────
function InfoTab({ contact, announcements }) {
  return (
    <div className="fade-up" style={{ padding: "20px 16px 0" }}>
      <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 28, fontWeight: 600, marginBottom: 20 }}>Information</div>

      {/* CELEX card */}
      <div style={{ background: "linear-gradient(140deg, #1c2b1a, #2d4a2a)", borderRadius: 18, padding: "22px 20px", marginBottom: 20 }}>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontStyle: "italic", fontSize: 13, color: "#8faf8a", marginBottom: 8 }}>Organised by</div>
        <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 28, fontWeight: 700, color: "#f5f0e8", marginBottom: 2 }}>CELEX</div>
        <div style={{ fontSize: 13, color: "#8faf8a", marginBottom: 16 }}>The global standard for luxury wedding professionals</div>
        {[
          { icon: "📞", label: "Phone", value: contact.phone },
          { icon: "✉️", label: "Email", value: contact.email },
          { icon: "🌐", label: "Website", value: contact.website },
        ].map(item => (
          <div key={item.label} style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 8 }}>
            <span style={{ fontSize: 14 }}>{item.icon}</span>
            <div>
              <div style={{ fontSize: 10, color: "#6b8a68", letterSpacing: .5, textTransform: "uppercase" }}>{item.label}</div>
              <div style={{ fontSize: 13, color: "#d4c9b4", fontWeight: 500 }}>{item.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* All announcements */}
      <SectionHead title="All Announcements" />
      {announcements.map(a => <AnnouncementCard key={a.id} a={a} />)}

      {/* Logistics */}
      <SectionHead title="Logistics" style={{ marginTop: 8 }} />
      {[
        { icon: "🧳", title: "Luggage Transfers", desc: "CELEX handles all luggage transfers between properties. Leave bags with concierge by 08:00 on transfer days." },
        { icon: "🚐", title: "Transportation", desc: "All group transfers are included. Private vehicle arrangements available on request through your CELEX coordinator." },
        { icon: "🍽️", title: "Dietary Requirements", desc: "Please notify your CELEX coordinator of any dietary requirements at least 48 hours in advance." },
        { icon: "⚕️", title: "Emergency Contact", desc: "CELEX 24/7 support line: +44 7354 258845. Local emergency services: 911." },
      ].map(item => (
        <div key={item.title} style={{ background: "#fffdf8", border: "1px solid #e4d9c6", borderRadius: 14, padding: "12px 14px", marginBottom: 8, display: "flex", gap: 12 }}>
          <span style={{ fontSize: 20 }}>{item.icon}</span>
          <div>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2, color: "#1c2b1a" }}>{item.title}</div>
            <div style={{ fontSize: 12, color: "#7a8c78", lineHeight: 1.5 }}>{item.desc}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Day Detail Sheet ─────────────────────────────────────────────────────────
function DaySheet({ day, saved, toggleSave, onClose }) {
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "#00000050", zIndex: 100, display: "flex", alignItems: "flex-end" }}>
      <div className="fade-up" onClick={e => e.stopPropagation()} style={{
        background: "#fffdf8", borderRadius: "24px 24px 0 0",
        width: "100%", maxWidth: 480, padding: "24px 20px 40px",
        maxHeight: "80vh", overflowY: "auto",
        border: "1px solid #e4d9c6", borderBottom: "none",
        margin: "0 auto",
      }}>
        <div style={{ width: 40, height: 4, background: "#e4d9c6", borderRadius: 2, margin: "0 auto 20px" }} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
          <div>
            <div style={{ fontFamily: "Cormorant Garamond, serif", fontStyle: "italic", fontSize: 13, color: day.color, marginBottom: 2 }}>{day.date} · Day {day.day}</div>
            <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 26, fontWeight: 700, color: "#1c2b1a", lineHeight: 1.1 }}>{day.theme}</div>
            <div style={{ fontSize: 13, color: "#9e8c6e", marginTop: 4 }}>📍 {day.location}</div>
          </div>
          <button onClick={() => toggleSave(day.day)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 24, color: saved ? "#b8955a" : "#d4c9b4" }}>{saved ? "♥" : "♡"}</button>
        </div>
        <div style={{ height: 1, background: "#ede5d4", marginBottom: 20 }} />
        {day.activities.map((act, i) => (
          <div key={i} style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", gap: 3, alignItems: "center", marginBottom: 6 }}>
              <span style={{ color: day.color, fontSize: 12 }}>◆</span>
              <span style={{ fontSize: 11, fontWeight: 600, color: "#9e8c6e", letterSpacing: .8, textTransform: "uppercase" }}>{act.time}</span>
            </div>
            <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 19, fontWeight: 600, color: "#1c2b1a", marginBottom: 4 }}>{act.title}</div>
            <div style={{ fontSize: 13, color: "#7a8c78", lineHeight: 1.6 }}>{act.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Shared Components ────────────────────────────────────────────────────────
function SectionHead({ title }) {
  return (
    <div style={{ fontFamily: "Cormorant Garamond, serif", fontSize: 20, fontWeight: 600, margin: "4px 0 10px", color: "#1c2b1a" }}>{title}</div>
  );
}

function AnnouncementCard({ a }) {
  return (
    <div style={{
      background: "#fffdf8", border: "1px solid #e4d9c6", borderRadius: 14,
      padding: "12px 14px", marginBottom: 8, display: "flex", gap: 12,
    }}>
      <div style={{ fontSize: 22 }}>{a.icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: 13, color: "#1c2b1a", marginBottom: 2 }}>{a.title}</div>
        <div style={{ fontSize: 12, color: "#7a8c78", lineHeight: 1.5 }}>{a.body}</div>
        <div style={{ fontSize: 10, color: "#b8a990", marginTop: 4 }}>{a.time}</div>
      </div>
      {a.pinned && <div style={{ fontSize: 10, color: "#b8955a", fontWeight: 600, marginTop: 1 }}>📌</div>}
    </div>
  );
}
